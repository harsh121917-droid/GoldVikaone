import 'package:get/get.dart';
import 'package:vikaone/data/repositories/transaction_repository.dart';
import 'package:vikaone/data/repositories/wallet_repository.dart';
import 'package:vikaone/modules/home/controllers/digi_gold_controller.dart';
import 'package:vikaone/modules/wallet/controllers/wallet_controller.dart';
import 'package:vikaone/data/repositories/gold_repository.dart';
import '../controllers/main_shell_controller.dart';
import '../../../data/repositories/investment_repository.dart';
import '../../../data/repositories/saving_repository.dart';
import '../../auth/controllers/auth_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    // Repositories
    Get.lazyPut<InvestmentRepository>(() => InvestmentRepository());
    Get.lazyPut<SavingRepository>(() => SavingRepository());
    Get.lazyPut<TransactionRepository>(() => TransactionRepository());

    // Controllers
    Get.lazyPut<AuthController>(() => AuthController());
    Get.lazyPut<MainShellController>(() => MainShellController());
    Get.lazyPut<WalletRepository>(() => WalletRepository());
    Get.lazyPut<WalletController>(() => WalletController());
    Get.lazyPut<GoldRepository>(() => GoldRepository());
    Get.lazyPut<GoldController>(() => GoldController());
  }
}
