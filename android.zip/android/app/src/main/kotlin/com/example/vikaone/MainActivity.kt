package com.example.vikaone

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
